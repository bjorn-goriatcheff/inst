// Copyright (c) 2017 Oleg Bulkin
// MIT License (https://opensource.org/licenses/MIT)

// Needed prototypes
PyObject *rdlevenshtein(PyObject *self, PyObject *args);
PyObject *rdlevenshtein_norm(PyObject *self, PyObject *args);
